"""Judge self-checks: explicit synthetic injections, not new Agent runs."""
import copy
import json
import math
import subprocess
import sys
from pathlib import Path
from judge import compare

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = ROOT / "artifacts/w03/judge-checks"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    cases = json.loads((HERE / "tests.json").read_text())
    by_id = {c["id"]: c for c in cases}
    real_path = ROOT / "artifacts/w03/chat-runs/86471e9b-6c8a-4999-b19a-b51c716b1b2d/result.json"
    real = json.loads(real_path.read_text())
    base = by_id["aug-net-sales"]["expected"]
    records = []

    def check(name, expected, actual, wanted, origin, mutation="", persist=True):
        comparison = compare(expected, actual)
        assert comparison["passed"] is wanted, (name, comparison)
        assert comparison["passed"] == (not comparison["differences"])
        # Compare the same input through the real stdin/stdout interface.
        if persist:
            payload = {"expected": expected, "actual": actual}
            path = OUT / (name + ".json")
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            result = subprocess.run([sys.executable, str(HERE / "judge.py")], input=json.dumps(payload, ensure_ascii=False), capture_output=True, text=True, check=True)
            parsed = json.loads(result.stdout)
            assert parsed == comparison, name
        records.append({"id": name, "origin": origin, "mutation": mutation,
                        "expected_passed": wanted, "comparison": comparison,
                        "cli_checked": persist})

    check("original-real-result", base, real, True, str(real_path.relative_to(ROOT)))
    for case in cases:
        check("self-"+case["id"], case["expected"], copy.deepcopy(case["expected"]), True,
              "synthetic self-comparison of independent expectation, not an Agent run")
    mutations = {
        "wrong-date": lambda a: a["intent"].update(end="2026-08-31"),
        "wrong-metric": lambda a: a["intent"].update(metrics=["payment_cents"]),
        "extra-filter": lambda a: a["intent"]["filters"].append({"field":"store","op":"eq","value":"S01"}),
        "wrong-group-role": lambda a: a["intent"].update(group_by=["home_store"]),
        "wrong-unit": lambda a: a["units"].update(net_sales_cents="yuan"),
        "wrong-value": lambda a: a["rows"][0].__setitem__(0, a["rows"][0][0]+1),
        "error-with-correct-rows": lambda a: a.update(status="error"),
        "error-marker-disguised-as-ok": lambda a: a.update(code="NATIVE_QUERY_FAILED"),
        "wrong-data-version": lambda a: a.update(data_version="wrong-version"),
        "wrong-data-hash": lambda a: a.update(data_sha256="wrong-hash"),
        "wrong-library-hash": lambda a: a.update(catalog_sha256="wrong-hash"),
        "missing-version": lambda a: a.pop("data_version"),
        "missing-unit": lambda a: a.pop("units"),
        "extra-unit": lambda a: a["units"].update(payment_cents="cents"),
        "duplicate-column": lambda a: a["columns"].append("net_sales_cents"),
        "row-width": lambda a: a["rows"][0].append(1),
        "missing-row": lambda a: a.update(rows=[]),
        "duplicate-aggregate-row": lambda a: a["rows"].append(copy.deepcopy(a["rows"][0])),
        "boolean-value": lambda a: a["rows"][0].__setitem__(0, True),
        "numeric-string": lambda a: a["rows"][0].__setitem__(0, str(a["rows"][0][0])),
    }
    for name, mutation in mutations.items():
        actual = copy.deepcopy(real)
        mutation(actual)
        check(name, base, actual, False, "synthetic single-field mutation of archived real result", name)

    grouped = by_id["july-net-by-store"]["expected"]
    actual = copy.deepcopy(grouped);actual["rows"].reverse()
    check("group-row-order", grouped, actual, True, "synthetic grouped result", "row order only")
    for name, mutate in {
        "missing-group": lambda a:a["rows"].pop(),
        "duplicate-group": lambda a:a["rows"].append(copy.deepcopy(a["rows"][0])),
        "extra-group": lambda a:a["rows"].append(["S99", 0]),
    }.items():
        actual=copy.deepcopy(grouped);mutate(actual)
        check(name,grouped,actual,False,"synthetic grouped result",name)
    actual=copy.deepcopy(grouped);actual["columns"].reverse();actual["rows"]=[list(reversed(r)) for r in actual["rows"]]
    check("column-order",grouped,actual,True,"synthetic grouped result","columns and values reordered together")
    actual=copy.deepcopy(grouped);actual["columns"].reverse()
    check("column-swap-without-values",grouped,actual,False,"synthetic grouped result","columns changed without corresponding values")
    multi=by_id["aug-order-counts"]["expected"];actual=copy.deepcopy(multi);actual["intent"]["metrics"].reverse()
    check("metric-order",multi,actual,True,"synthetic multi-metric result","metric order only")
    actual=copy.deepcopy(multi);actual["intent"]["metrics"].append(actual["intent"]["metrics"][0])
    check("duplicate-metric",multi,actual,False,"synthetic multi-metric result","duplicate metric")
    filters=by_id["aug-s01-miniapp-net"]["expected"];actual=copy.deepcopy(filters);actual["intent"]["filters"].reverse()
    check("and-filter-order",filters,actual,True,"synthetic filtered result","AND filter order only")
    expected=copy.deepcopy(base);expected["intent"]["filters"]=[{"field":"store","op":"in","value":["S01","S02"]}]
    actual=copy.deepcopy(expected);actual["intent"]["filters"][0]["value"].reverse()
    check("in-value-order",expected,actual,True,"synthetic intent normalization fixture","in value order only; values are not a live query result")

    null=by_id["empty-month-zero-null"]["expected"];actual=copy.deepcopy(null);actual["rows"][0][2]=0
    check("null-to-zero",null,actual,False,"synthetic null fixture","null replaced by zero")
    rate=by_id["aug-refund-cancel-discount-rates"]["expected"];actual=copy.deepcopy(rate);actual["rows"][0][0]*=100
    check("ratio-as-percent",rate,actual,False,"synthetic ratio fixture","raw ratio multiplied by 100")
    for name,want,got,passed in [
        ("integer-as-float",13000,13000.0,True),
        ("integer-one-cent",13000,13001,False),
        ("large-integer-one-cent",1000000000,1000000001,False),
        ("large-int-float-rounding",9007199254740993,9007199254740992.0,False),
        ("float-within-tolerance",0.25,0.25000005,True),
        ("float-outside-tolerance",0.25,0.2500002,False),
        ("large-float-one-cent",1000000000.0,1000000001.0,False),
        ("zero-not-boolean",0,False,False),
        ("null-only-null",None,None,True),
    ]:
        expected=copy.deepcopy(base);expected["rows"]=[[want]];actual=copy.deepcopy(expected);actual["rows"]=[[got]]
        check(name,expected,actual,passed,"synthetic numeric comparison fixture",name)
    for name,value in [("nan",float("nan")),("infinity",float("inf"))]:
        actual=copy.deepcopy(real);actual["rows"][0][0]=value
        check(name,base,actual,False,"in-process defensive fixture, not legal JSON",name,persist=False)
    invalid = subprocess.run([sys.executable,str(HERE/"judge.py")],input="not json",capture_output=True,text=True,check=True)
    assert json.loads(invalid.stdout)["passed"] is False
    smoke={"expected":{"status":"clarify"},"actual":{"status":"ok"}}
    (OUT/"smoke.json").write_text(json.dumps(smoke,ensure_ascii=False)+'\n')
    check("smoke-status",smoke["expected"],smoke["actual"],False,"task-book smoke input","status differs")
    report={"scope":"judge self-check only; no model calls; not completion of course step 10",
            "float_policy":{"relative_tolerance":0.0,"absolute_tolerance":1e-7,"integers":"exact","null":"null only"},
            "passed":True,"total":len(records),"all_injections_rejected":True,"records":records}
    (OUT/"judge_selfcheck_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps({"self_checks":len(records),"passed":True,"model_calls":0,"report":str(OUT/'judge_selfcheck_report.json')},ensure_ascii=False))


if __name__ == '__main__':
    main()
