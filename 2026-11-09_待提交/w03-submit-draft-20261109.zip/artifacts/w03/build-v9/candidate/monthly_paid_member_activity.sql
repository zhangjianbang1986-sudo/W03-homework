WITH valid_orders AS (
  SELECT * FROM {{ ref('orders') }}
  WHERE status = 'paid' AND (paid_cents - refund_cents) > 0
),
member_month AS (
  SELECT member_id,
         CAST(date_trunc('month', ordered_at) AS DATE) AS month_start,
         COUNT(*) AS valid_order_count,
         SUM(paid_cents - refund_cents) AS valid_net_sales_cents
  FROM valid_orders
  GROUP BY member_id, CAST(date_trunc('month', ordered_at) AS DATE)
),
eligible AS (
  SELECT mm.*
  FROM member_month mm
  WHERE EXISTS (
    SELECT 1
    FROM {{ ref('cards') }} c
    WHERE c.member_id = mm.member_id
      AND c.card_type IN ('悦享年卡', '家庭季卡')
      AND c.valid_from <= CAST(last_day(mm.month_start) AS DATE)
      AND CAST(last_day(mm.month_start) AS DATE) < c.valid_until
      AND (c.ended_at IS NULL OR CAST(last_day(mm.month_start) AS DATE) < c.ended_at)
  )
)
SELECT
  member_id || '|' || CAST(month_start AS VARCHAR) AS member_month_key,
  member_id,
  month_start,
  valid_order_count,
  valid_net_sales_cents,
  CASE WHEN valid_order_count >= 2 THEN TRUE ELSE FALSE END AS is_repeat_buyer
FROM eligible