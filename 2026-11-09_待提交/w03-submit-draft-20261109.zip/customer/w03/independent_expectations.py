"""Compute expectations from raw CSV only; never import the tested library/SQL."""
import calendar
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path


RATIOS = {
    "avg_order_value": ("net_sales_cents", "valid_order_count"),
    "avg_buyer_value": ("net_sales_cents", "buyer_count"),
    "purchase_frequency": ("valid_order_count", "buyer_count"),
    "refund_amount_rate": ("refund_cents", "payment_cents"),
    "cancel_rate": ("cancelled_order_count", "order_count"),
    "refund_order_rate": ("refund_order_count", "paid_order_count"),
    "discount_rate": ("discount_cents", "gross_cents"),
    "items_per_order": ("valid_order_items", "valid_order_count"),
    "monthly_repeat_rate": ("monthly_repeat_buyer_count", "monthly_buyer_count"),
    "monthly_paid_repeat_rate": ("monthly_paid_repeat_buyer_count", "monthly_paid_buyer_count"),
    "monthly_paid_avg_order_value": ("monthly_paid_sales_cents", "monthly_paid_order_count"),
}


class IndependentAudit:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.manifest = json.loads((self.folder / "manifest.json").read_text())
        self.hashes = {}
        for name in ("orders", "members", "stores", "cards"):
            path = self.folder / (name + ".csv")
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != self.manifest["sha256"][path.name]:
                raise ValueError("CSV_HASH_MISMATCH:" + path.name)
            self.hashes[path.name] = digest
            with path.open(newline="") as handle:
                setattr(self, name, list(csv.DictReader(handle)))
        for row in self.orders:
            for name in ("gross_cents", "paid_cents", "refund_cents", "quantity"):
                row[name] = int(row[name])
        self.member_index = {r["member_id"]: r for r in self.members}
        self.store_index = {r["store_id"]: r for r in self.stores}
        history = defaultdict(list)
        for row in sorted(self.orders, key=lambda r: (r["ordered_at"], r["order_id"])):
            if self.valid(row):
                history[row["member_id"]].append(row)
        self.first = [rows[0] for rows in history.values()]
        self.repeat = [r for rows in history.values() for r in rows[1:]]

    @staticmethod
    def valid(row):
        return row["status"] == "paid" and row["paid_cents"] > row["refund_cents"]

    def calculate(self, start, end):
        selected = [r for r in self.orders if start <= r["ordered_at"] < end]
        paid = [r for r in selected if r["status"] == "paid"]
        valid = [r for r in selected if self.valid(r)]
        refunds = [r for r in paid if r["refund_cents"] > 0]
        first = [r for r in self.first if start <= r["ordered_at"] < end]
        repeat = [r for r in self.repeat if start <= r["ordered_at"] < end]
        counts = defaultdict(int)
        for row in valid:
            counts[row["member_id"]] += 1
        values = {
            "order_count": len(selected),
            "paid_order_count": len(paid),
            "valid_order_count": len(valid),
            "cancelled_order_count": sum(r["status"] == "cancelled" for r in selected),
            "refund_order_count": len(refunds),
            "partial_refund_order_count": sum(0 < r["refund_cents"] < r["paid_cents"] for r in paid),
            "full_refund_order_count": sum(r["paid_cents"] > 0 and r["refund_cents"] == r["paid_cents"] for r in paid),
            "payment_cents": sum(r["paid_cents"] for r in paid),
            "refund_cents": sum(r["refund_cents"] for r in paid),
            "net_sales_cents": sum(r["paid_cents"] - r["refund_cents"] for r in paid),
            "gross_cents": sum(r["gross_cents"] for r in paid),
            "discount_cents": sum(r["gross_cents"] - r["paid_cents"] for r in paid),
            "buyer_count": len(counts),
            "refund_buyer_count": len({r["member_id"] for r in refunds}),
            "selling_store_count": len({r["store_id"] for r in valid}),
            "valid_order_items": sum(r["quantity"] for r in valid),
            "new_member_count": sum(start <= r["registered_at"] < end for r in self.members),
            "first_buyer_count": len({r["member_id"] for r in first}),
            "first_order_sales_cents": sum(r["paid_cents"] - r["refund_cents"] for r in first),
            "first_order_count": len(first),
            "repeat_order_count": len(repeat),
        }
        eligible_cards = []
        paid_counts = {}
        year, month = map(int, start[:7].split("-"))
        next_month = f"{year + (month == 12):04d}-{month % 12 + 1:02d}-01"
        if start.endswith("-01") and end == next_month:
            month_end = f"{year:04d}-{month:02d}-{calendar.monthrange(year, month)[1]:02d}"
            eligible_cards = [r for r in self.cards if
                r["card_type"] in ("悦享年卡", "家庭季卡")
                and r["valid_from"] <= month_end < r["valid_until"]
                and (not r["ended_at"] or month_end < r["ended_at"])]
            eligible = {r["member_id"] for r in eligible_cards}
            paid_orders = [r for r in valid if r["member_id"] in eligible]
            paid_counts = defaultdict(int)
            for row in paid_orders:
                paid_counts[row["member_id"]] += 1
            values.update({
                "monthly_buyer_count": len(counts),
                "monthly_repeat_buyer_count": sum(n >= 2 for n in counts.values()),
                "monthly_paid_buyer_count": len(paid_counts),
                "monthly_paid_order_count": len(paid_orders),
                "monthly_paid_sales_cents": sum(r["paid_cents"] - r["refund_cents"] for r in paid_orders),
                "monthly_paid_repeat_buyer_count": sum(n >= 2 for n in paid_counts.values()),
            })
        for name, (numerator, denominator) in RATIOS.items():
            if numerator in values and denominator in values:
                values[name] = values[numerator] / values[denominator] if values[denominator] else None
        audit = {
            "start": start, "end": end, "values": values,
            "selected_orders": [r["order_id"] for r in selected],
            "paid_orders": [r["order_id"] for r in paid],
            "valid_orders": [r["order_id"] for r in valid],
            "refund_orders": [r["order_id"] for r in refunds],
            "refund_accounts": sorted({r["member_id"] for r in refunds}),
            "first_orders": [r["order_id"] for r in first],
            "repeat_orders": [r["order_id"] for r in repeat],
            "valid_orders_per_account": dict(sorted(counts.items())),
            "eligible_cards_at_month_end": eligible_cards,
            "paid_valid_orders_per_account": dict(sorted(paid_counts.items())),
            "payment_sum": values["payment_cents"], "refund_sum": values["refund_cents"],
        }
        return values, audit

    def net_sales_groups(self, start, end, group):
        totals = defaultdict(int)
        for row in self.orders:
            if not start <= row["ordered_at"] < end:
                continue
            if group == "store":
                key = row["store_id"]
            elif group == "home_store":
                key = self.member_index[row["member_id"]]["home_store_id"]
            elif group == "member__tier":
                key = self.member_index[row["member_id"]]["tier"]
            else:
                raise ValueError("UNKNOWN_GROUP")
            totals[key] += row["paid_cents"] - row["refund_cents"] if row["status"] == "paid" else 0
        return [[key, value] for key, value in sorted(totals.items())]

    def filtered_net_sales(self, start, end, channel=None, store=None):
        rows = [r for r in self.orders if start <= r["ordered_at"] < end
            and (channel is None or r["channel"] == channel)
            and (store is None or r["store_id"] == store)]
        return sum(r["paid_cents"] - r["refund_cents"] for r in rows if r["status"] == "paid"), [r["order_id"] for r in rows]
