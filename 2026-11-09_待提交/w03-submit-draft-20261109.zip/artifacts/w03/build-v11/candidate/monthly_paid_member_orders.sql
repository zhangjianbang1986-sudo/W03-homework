WITH member_months AS (
  SELECT
    member_id,
    CAST(date_trunc('month', ordered_at) AS DATE) AS month_start,
    COUNT(*) AS valid_order_count,
    SUM(paid_cents - refund_cents) AS net_sales_cents
  FROM {{ ref('orders') }}
  WHERE status = 'paid'
    AND paid_cents - refund_cents > 0
  GROUP BY member_id, CAST(date_trunc('month', ordered_at) AS DATE)
),
month_ends AS (
  SELECT
    member_id,
    month_start,
    CAST(date_trunc('month', month_start) + INTERVAL '1 month' - INTERVAL '1 day' AS DATE) AS month_end
  FROM member_months
),
qualified AS (
  SELECT DISTINCT me.member_id, me.month_start
  FROM month_ends me
  JOIN {{ ref('cards') }} c
    ON c.member_id = me.member_id
   AND c.card_type IN ('悦享年卡', '家庭季卡')
   AND c.valid_from <= me.month_end
   AND me.month_end < c.valid_until
   AND (c.ended_at IS NULL OR me.month_end < c.ended_at)
)
SELECT
  q.member_id || '|' || CAST(q.month_start AS VARCHAR) AS member_month_key,
  q.member_id,
  q.month_start,
  mm.valid_order_count,
  mm.net_sales_cents,
  CASE WHEN mm.valid_order_count >= 1 THEN 1 ELSE 0 END AS has_valid_order,
  CASE WHEN mm.valid_order_count >= 2 THEN 1 ELSE 0 END AS has_repeat
FROM qualified q
JOIN member_months mm
  ON mm.member_id = q.member_id
 AND mm.month_start = q.month_start