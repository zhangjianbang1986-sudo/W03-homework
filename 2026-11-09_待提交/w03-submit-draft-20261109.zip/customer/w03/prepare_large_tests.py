"""Freeze independent scale-data expectations; never query the tested metrics."""
import hashlib
import json
from pathlib import Path
from independent_expectations import IndependentAudit, RATIOS

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def main():
    audit = IndependentAudit(ROOT / 'materials/data/large')
    metadata = json.loads((ROOT/'.runtime/qinghe-large-v1/dataset.json').read_text())
    if metadata['id'] != audit.manifest['id'] or metadata['sha256'] != audit.hashes:
        raise ValueError('LOADED_DATA_VERSION_MISMATCH')
    versions = {'data_version':metadata['id'],
        'data_sha256':hashlib.sha256(json.dumps({k:v for k,v in metadata.items() if k!='library_sha256'},sort_keys=True).encode()).hexdigest(),
        'catalog_sha256':metadata['library_sha256']}
    units={'avg_order_value':'cents_per_order','avg_buyer_value':'cents_per_account',
        'purchase_frequency':'orders_per_account','items_per_order':'items_per_order',
        'monthly_paid_avg_order_value':'cents_per_order'}
    def unit(k):return units.get(k,'ratio' if k in RATIOS else 'cents' if k.endswith('_cents') else 'count')
    periods={}
    def values(start,end):
        key=start+'_'+end
        if key not in periods:
            _,periods[key]=audit.calculate(start,end)
        return periods[key]['values']
    cases=[]
    def ok(cid,q,ids,rule,start='2026-08-01',end='2026-09-01',group=None,rows=None,extra=''):
        v=values(start,end)
        details=[]
        for k in ids:
            if k in RATIOS:
                a,b=RATIOS[k];details.append(f'{k}={v[a]}÷{v[b]}={v[k]}' if v[b] else f'{k}分母为零，未定义')
            else:details.append(f'{k}={v[k]}')
        expected={'status':'ok','intent':{'metrics':ids,'start':start,'end':end,'group_by':group or [],'filters':[]},
            'columns':(group or [])+ids,'rows':rows if rows is not None else [[v[k] for k in ids]],
            'units':{k:unit(k) for k in ids},**versions}
        src=f"独立读取{audit.manifest['id']}的原始规模CSV，按[{start},{end})计算。{rule} {'；'.join(details)}。{extra}逐笔订单、账户和卡的可复核清单见artifacts/w03/test-preparation/independent-large-values.json；计算代码为customer/w03/independent_expectations.py，不读取被测SQL或Agent结果。"
        cases.append({'id':cid,'question':q,'expected':expected,'expected_source':src})
    ok('large-order-counts','2026年8月青禾的创建订单数、支付订单数、有效订单数和取消订单数分别是多少？',['order_count','paid_order_count','valid_order_count','cancelled_order_count'],'订单日报：创建包含取消；支付包含全退；有效为paid且实付减退款大于零。')
    ok('large-refund-counts','2026年8月青禾退款订单数、部分退款订单数、全额退款订单数和退款会员数分别是多少？',['refund_order_count','partial_refund_order_count','full_refund_order_count','refund_buyer_count'],'按订单日报及学员确定的本期退款账户原订单日期口径，窗口内paid订单按累计退款分类；账户去重，全渠道。')
    ok('large-money','2026年8月青禾实付金额、退款金额、净销售额、支付订单原价金额和优惠金额分别是多少？',['payment_cents','refund_cents','net_sales_cents','gross_cents','discount_cents'],'paid订单实付、退款和原价逐单求和；净销售额实付减退款，优惠原价减实付；金额单位分。')
    ok('large-money-synonym','2026年8月青禾已支付订单扣掉退款后净销售额总共多少钱？',['net_sales_cents'],'同义问法，仍按paid订单原下单日期、全渠道全门店汇总。')
    ok('large-money-reference','2026年8月青禾的净销售额是多少？',['net_sales_cents'],'标准问法，与同义用例的时间、指标和范围一致。')
    ok('large-accounts-stores-items','2026年8月青禾的购买会员数、成交门店数、有效订单商品件数和注册会员数分别是多少？',['buyer_count','selling_store_count','valid_order_items','new_member_count'],'有效订单对应账户和成交门店去重，原始商品件数求和；注册账户以members.registered_at统计。')
    ok('large-averages','2026年8月青禾有效订单均额、购买会员人均消费、购买频次和单均商品件数分别是多少？',['avg_order_value','avg_buyer_value','purchase_frequency','items_per_order'],'财务邮件分别按净销售额/有效订单、净销售额/购买账户、有效订单/购买账户、有效订单件数/有效订单数计算。')
    ok('large-ratios','2026年8月青禾退款金额占比、取消率、退款订单率和优惠率分别是多少？',['refund_amount_rate','cancel_rate','refund_order_rate','discount_rate'],'财务邮件各自分子分母求比率，原始值不乘100，零分母未定义。')
    ok('large-first-repeat','2026年8月青禾观测期首购会员数、观测期首单数、观测期首单净销售额和观测期后续购买订单数分别是多少？',['first_buyer_count','first_order_count','first_order_sales_cents','repeat_order_count'],'先按全覆盖期、账户、订单日期和订单号排序，再筛8月；不是终身首购。')
    monthly=['monthly_buyer_count','monthly_repeat_buyer_count','monthly_repeat_rate']
    ok('large-monthly-repeat','2026年8月青禾全渠道全门店的月内购买会员数、月内复购会员数和月内复购率分别是多少？',monthly,'账户按自然月计有效订单，至少1笔购买、至少2笔复购，不筛付费资格。')
    paid=['monthly_paid_buyer_count','monthly_paid_order_count','monthly_paid_sales_cents','monthly_paid_repeat_buyer_count','monthly_paid_repeat_rate','monthly_paid_avg_order_value']
    rule='统计确认邮件与本人访谈：月末按账户判断悦享年卡或家庭季卡有效；开始日包含，结束及提前终止日不包含；多卡去重后统计全月全渠道全门店有效订单。'
    for month in (7,8):
        ok(f'large-paid-{month}',f'2026年{month}月青禾全渠道全门店的月末付费会员购买人数、有效订单数、净销售额、复购人数、复购率和订单均额分别是多少？',paid,rule,start=f'2026-{month:02d}-01',end=f'2026-{month+1:02d}-01')
    for role,label in [('store','订单成交门店编号'),('home_store','会员归属门店编号')]:
        rows=audit.net_sales_groups('2026-07-01','2026-08-01',role)
        ok('large-july-net-by-'+role,f'2026年7月青禾净销售额按{label}分组分别是多少？',['net_sales_cents'],'paid订单实付减退款，按下单日期；归属门店通过member_id查members.home_store_id，成交门店使用orders.store_id。',start='2026-07-01',end='2026-08-01',group=[role],rows=rows,extra='分组独立期望：'+json.dumps(rows,ensure_ascii=False))
    for cid,q,status,why in [
        ('large-missing-period','青禾净销售额是多少？','clarify','未提供日期，须澄清。'),
        ('large-outside','2026年9月青禾净销售额是多少？','unsupported','结束日2026-09-01不含，9月超出覆盖。'),
        ('large-half-month','2026年8月1日至8月15日青禾月内复购率是多少？','unsupported','月内复购率要求完整自然月。'),
        ('large-paid-by-store','2026年8月青禾月末付费会员净销售额按成交门店分别是多少？','unsupported','付费月报限全门店，不支持门店分组。')]:
        cases.append({'id':cid,'question':q,'expected':{'status':status},'expected_source':why})
    targets={x['id'] for x in json.loads((HERE/'targets.json').read_text())}
    covered={m for c in cases if c['expected']['status']=='ok' for m in c['expected']['intent']['metrics']}
    assert covered==targets,(targets-covered,covered-targets)
    assert len({c['id'] for c in cases})==len(cases)
    out=ROOT/'artifacts/w03/test-preparation';out.mkdir(parents=True,exist_ok=True)
    evidence={'data_version':audit.manifest['id'],'csv_sha256':audit.hashes,'periods':periods,'note':'规模原始CSV独立期望，不是Agent查询结果；退款会员数按学员确定的本期选择。'}
    (out/'independent-large-values.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    data=json.dumps(cases,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    target=HERE/'tests-large.json';frozen=out/'tests-large-v1.json'
    for p in [target,frozen]:
        if p.exists() and p.read_text()!=data:raise ValueError('OUTPUT_EXISTS_WITH_DIFFERENT_CONTENT:'+str(p))
        if not p.exists():p.write_text(data)
    print(json.dumps({'cases':len(cases),'covered_metrics':len(covered),'data_version':audit.manifest['id'],'data_counts':audit.manifest['counts'],'live_test_performed':False},ensure_ascii=False))


if __name__=='__main__':main()
