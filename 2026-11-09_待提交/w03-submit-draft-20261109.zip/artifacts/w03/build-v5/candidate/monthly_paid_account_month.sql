with valid_orders as (
  select order_id, member_id, ordered_at,
         date_trunc('month', ordered_at)::date as month_start,
         paid_cents - refund_cents as net_sales_cents
  from {{ ref('orders') }}
  where status = 'paid' and paid_cents - refund_cents > 0
), eligible_member_months as (
  select distinct o.member_id, o.month_start
  from valid_orders o
  join {{ ref('cards') }} c on c.member_id = o.member_id
  where c.card_type in ('悦享年卡', '家庭季卡')
    and c.valid_from <= (o.month_start + interval 1 month - interval 1 day)::date
    and (o.month_start + interval 1 month - interval 1 day)::date < c.valid_until
    and (c.ended_at is null or (o.month_start + interval 1 month - interval 1 day)::date < c.ended_at)
), account_month as (
  select o.member_id, o.month_start,
         count(*) as valid_order_count,
         sum(o.net_sales_cents) as net_sales_cents
  from valid_orders o
  join eligible_member_months e on e.member_id = o.member_id and e.month_start = o.month_start
  group by 1, 2
)
select * from account_month