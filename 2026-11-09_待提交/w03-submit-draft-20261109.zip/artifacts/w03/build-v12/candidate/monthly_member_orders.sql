WITH valid_orders AS (
  SELECT
    member_id,
    ordered_at,
    paid_cents - refund_cents AS net_sales_cents,
    CAST(date_trunc('month', ordered_at) AS DATE) AS month_start
  FROM {{ ref('orders') }}
  WHERE status = 'paid'
    AND paid_cents - refund_cents > 0
)
SELECT
  member_id,
  month_start,
  member_id || '|' || CAST(month_start AS VARCHAR) AS member_month_key,
  COUNT(*) AS valid_order_count,
  SUM(net_sales_cents) AS net_sales_cents
FROM valid_orders
GROUP BY member_id, month_start