"""Deterministic comparison only: no models, database, network or reference files.

Integer expectations are exact. Finite float expectations use absolute 1e-7
tolerance and no relative tolerance. Null, booleans and numeric strings differ.
Metric/column/AND-filter ordering may vary; group keys and dates remain exact.
"""
import json
import math
import sys
from datetime import date

ABS_TOL = 1e-7
VERSION_FIELDS = ("data_version", "data_sha256", "catalog_sha256")
STATUSES = {"ok", "clarify", "unsupported", "error"}


def safe(value):
    if type(value) is float and not math.isfinite(value):
        return {"invalid_number": repr(value)}
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe(v) for v in value]
    return value


def number_equal(want, got):
    if want is None:
        return got is None
    if type(want) not in (int, float) or type(got) not in (int, float):
        return False
    if type(got) is float and not math.isfinite(got):
        return False
    if type(want) is int:
        return want == got
    if not math.isfinite(want):
        return False
    try:
        return math.isclose(want, got, rel_tol=0.0, abs_tol=ABS_TOL)
    except OverflowError:
        return False


def string_list(value, allow_empty=True):
    return (isinstance(value, list) and (allow_empty or bool(value))
            and all(type(v) is str and bool(v) for v in value)
            and len(value) == len(set(value)))


def normalize_intent(value):
    required = {"metrics", "start", "end", "group_by", "filters"}
    if not isinstance(value, dict) or set(value) != required:
        raise ValueError("意图必须恰好包含metrics、start、end、group_by、filters")
    if not string_list(value["metrics"], False) or not string_list(value["group_by"]):
        raise ValueError("指标或分组列表非法、重复或为空")
    for key in ("start", "end"):
        text = value[key]
        if type(text) is not str or date.fromisoformat(text).isoformat() != text:
            raise ValueError("日期须为YYYY-MM-DD")
    if value["start"] >= value["end"]:
        raise ValueError("时间范围须为非空半开区间")
    if not isinstance(value["filters"], list):
        raise ValueError("filters必须为数组")
    filters = []
    for item in value["filters"]:
        if not isinstance(item, dict) or set(item) != {"field", "op", "value"}:
            raise ValueError("筛选必须包含field、op、value")
        field, op, target = item["field"], item["op"], item["value"]
        if type(field) is not str or not field or type(op) is not str:
            raise ValueError("筛选字段或操作符非法")
        if op == "eq":
            if type(target) is not str or not target:
                raise ValueError("eq必须是非空字符串")
        elif op == "in":
            if not string_list(target, False):
                raise ValueError("in必须是无重复的非空字符串数组")
            target = sorted(target)
        else:
            raise ValueError("仅支持eq和in")
        filters.append(json.dumps({"field": field, "op": op, "value": target}, sort_keys=True, ensure_ascii=False))
    if len(filters) != len(set(filters)):
        raise ValueError("筛选条件重复")
    return {"metrics": sorted(value["metrics"]), "start": value["start"],
            "end": value["end"], "group_by": sorted(value["group_by"]),
            "filters": sorted(filters)}


def compare(expected, actual):
    errors = []

    def add(path, want, got, rule):
        errors.append(safe({"path": path, "expected": want, "actual": got, "rule": rule}))

    def result():
        return {"passed": not errors, "differences": errors}

    if not isinstance(expected, dict) or not isinstance(actual, dict):
        add("result", "expected和actual均为对象", [expected, actual], "structure")
        return result()
    status = expected.get("status")
    if type(status) is not str or status not in STATUSES:
        add("expected.status", sorted(STATUSES), status, "invalid_expectation")
        return result()
    if actual.get("status") != status:
        add("status", status, actual.get("status", "<missing>"), "exact")
        return result()
    for field in VERSION_FIELDS:
        if field in expected:
            if type(expected[field]) is not str or not expected[field]:
                add("expected."+field, "非空字符串", expected[field], "invalid_expectation")
            elif actual.get(field) != expected[field]:
                add(field, expected[field], actual.get(field, "<missing>"), "exact")
    if errors or status != "ok":
        return result()
    if actual.get("code") or actual.get("error"):
        add("result", "成功结果不带错误标记", {"code": actual.get("code"), "error": actual.get("error")}, "contradictory_success")
        return result()

    intents = {}
    for label, value in (("expected", expected), ("actual", actual)):
        try:
            intents[label] = normalize_intent(value.get("intent"))
        except (ValueError, TypeError) as exc:
            add(label+".intent", "完整合法的意图", value.get("intent", "<missing>"), str(exc))
    if len(intents) == 2:
        for key in intents["expected"]:
            if intents["expected"][key] != intents["actual"][key]:
                add("intent."+key, expected["intent"][key], actual["intent"][key], "normalized_exact")
    if errors:
        return result()
    metrics = intents["expected"]["metrics"]
    groups = intents["expected"]["group_by"]
    if set(metrics) & set(groups):
        add("intent", "指标与分组名称不同", expected["intent"], "invalid_expectation")
        return result()
    want_units = expected.get("units")
    if (not isinstance(want_units, dict) or set(want_units) != set(metrics)
            or not all(type(v) is str and bool(v) for v in want_units.values())):
        add("expected.units", "所有指标的单位映射", want_units, "invalid_expectation")
    if actual.get("units") != want_units or not isinstance(actual.get("units"), dict):
        add("units", want_units, actual.get("units", "<missing>"), "exact_keys_and_units")

    tables = {}
    wanted_columns = set(metrics) | set(groups)
    for label, value in (("expected", expected), ("actual", actual)):
        columns = value.get("columns")
        rows = value.get("rows")
        if not string_list(columns, False) or set(columns) != wanted_columns:
            add(label+".columns", sorted(wanted_columns), columns, "unique_matching_columns")
            continue
        if not isinstance(rows, list):
            add(label+".rows", "二维数组", rows, "structure")
            continue
        if not groups and len(rows) != 1:
            add(label+".rows.length", 1, len(rows), "single_aggregate_row")
            continue
        index = {}
        for i, row in enumerate(rows):
            if not isinstance(row, list) or len(row) != len(columns):
                add(f"{label}.rows[{i}]", f"长度为{len(columns)}的数组", row, "row_width")
                continue
            item = dict(zip(columns, row))
            key_values = [item[g] for g in groups]
            if any(type(v) not in (str, int, float, type(None)) or
                   (type(v) is float and not math.isfinite(v)) for v in key_values):
                add(f"{label}.rows[{i}].group", "合法的标量分组键", key_values, "group_type")
                continue
            # Include type: strings, booleans, numbers, and null cannot collapse.
            key = tuple((type(v).__name__, json.dumps(v, ensure_ascii=False)) for v in key_values)
            if key in index:
                add(f"{label}.rows[{i}].group", "唯一分组键", dict(zip(groups, key_values)), "duplicate_group")
                continue
            index[key] = item
        tables[label] = index
    if errors or len(tables) != 2:
        return result()
    want, got = tables["expected"], tables["actual"]
    for key in sorted(want.keys() - got.keys()):
        add("rows.group", {g: want[key][g] for g in groups}, "<missing>", "missing_group")
    for key in sorted(got.keys() - want.keys()):
        add("rows.group", "<none>", {g: got[key][g] for g in groups}, "extra_group")
    for key in sorted(want.keys() & got.keys()):
        for metric in metrics:
            w, g = want[key][metric], got[key][metric]
            if not number_equal(w, g):
                rule = "null_exact" if w is None else "integer_exact" if type(w) is int else "float_abs_tol_1e-7"
                add("rows."+metric, {"group": {k: want[key][k] for k in groups}, "value": w}, g, rule)
    return result()


if __name__ == "__main__":
    try:
        data = json.load(sys.stdin)
        if not isinstance(data, dict) or "expected" not in data or "actual" not in data:
            raise ValueError("输入需要expected和actual")
        output = compare(data["expected"], data["actual"])
    except (ValueError, TypeError, KeyError) as exc:
        output = {"passed": False, "differences": [{"path": "input", "rule": "invalid_input", "detail": str(exc)}]}
    print(json.dumps(output, ensure_ascii=False, allow_nan=False))
