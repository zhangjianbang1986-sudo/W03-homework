WITH valid_orders AS (
  SELECT
    member_id,
    ordered_at,
    paid_cents - refund_cents AS net_sales_cents,
    CAST(date_trunc('month', ordered_at) AS DATE) AS month_start
  FROM {{ ref('orders') }}
  WHERE status = 'paid'
    AND paid_cents - refund_cents > 0
),
member_month AS (
  SELECT
    member_id,
    month_start,
    CAST(month_start + INTERVAL 1 MONTH - INTERVAL 1 DAY AS DATE) AS month_end,
    COUNT(*) AS valid_order_count,
    SUM(net_sales_cents) AS net_sales_cents
  FROM valid_orders
  GROUP BY member_id, month_start
),
eligible AS (
  SELECT mm.*
  FROM member_month mm
  WHERE EXISTS (
    SELECT 1
    FROM {{ ref('cards') }} c
    WHERE c.member_id = mm.member_id
      AND c.card_type IN ('悦享年卡', '家庭季卡')
      AND c.valid_from <= mm.month_end
      AND (c.ended_at IS NULL OR c.ended_at > mm.month_end)
      AND c.valid_until > mm.month_end
  )
)
SELECT
  member_id,
  month_start,
  member_id || '|' || CAST(month_start AS VARCHAR) AS paid_member_month_key,
  valid_order_count,
  net_sales_cents,
  CASE WHEN valid_order_count >= 1 THEN 1 ELSE 0 END AS is_paid_buyer,
  CASE WHEN valid_order_count >= 2 THEN 1 ELSE 0 END AS is_paid_repeat
FROM eligible