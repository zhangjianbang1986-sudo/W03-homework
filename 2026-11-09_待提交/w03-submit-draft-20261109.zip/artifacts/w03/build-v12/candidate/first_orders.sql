WITH valid_orders AS (
  SELECT
    order_id,
    member_id,
    ordered_at,
    paid_cents - refund_cents AS net_sales_cents,
    ROW_NUMBER() OVER (PARTITION BY member_id ORDER BY ordered_at, order_id) AS rn
  FROM {{ ref('orders') }}
  WHERE status = 'paid'
    AND paid_cents - refund_cents > 0
)
SELECT
  order_id,
  member_id,
  ordered_at AS first_order_date,
  net_sales_cents
FROM valid_orders
WHERE rn = 1