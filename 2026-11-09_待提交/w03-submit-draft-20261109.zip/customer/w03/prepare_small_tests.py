"""Prepare frozen small-data tests without asking the Agent or using its SQL."""
import hashlib
import argparse
import json
from pathlib import Path
from independent_expectations import IndependentAudit, RATIOS

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = ROOT / "artifacts/w03/test-preparation"


def main(project=".runtime/qinghe-small-v1"):
    audit = IndependentAudit(ROOT / "materials/data/small")
    metadata = json.loads((ROOT / project / "dataset.json").read_text())
    if metadata["id"] != audit.manifest["id"] or metadata["sha256"] != audit.hashes:
        raise ValueError("LOADED_DATA_VERSION_MISMATCH")
    versions = {
        "data_version": metadata["id"],
        "data_sha256": hashlib.sha256(json.dumps({k:v for k,v in metadata.items() if k != "library_sha256"}, sort_keys=True).encode()).hexdigest(),
        "catalog_sha256": metadata["library_sha256"],
    }
    OUT.mkdir(parents=True, exist_ok=True)
    original = json.loads((HERE / "tests.json").read_text())
    if not (OUT / "tests-before-completion.json").exists():
        (OUT / "tests-before-completion.json").write_text((HERE / "tests.json").read_text())
    units = {"avg_order_value":"cents_per_order", "avg_buyer_value":"cents_per_account", "purchase_frequency":"orders_per_account", "items_per_order":"items_per_order", "monthly_paid_avg_order_value":"cents_per_order"}
    def unit(name):
        return units.get(name, "ratio" if name in RATIOS else "cents" if name.endswith("_cents") else "count")
    periods = {}
    def values(start, end):
        key = start + "_" + end
        if key not in periods:
            value, evidence = audit.calculate(start, end)
            periods[key] = evidence
        return periods[key]["values"]
    def source(start, end, ids, rule):
        value = values(start, end)
        details = []
        for name in ids:
            if name in RATIOS:
                a,b = RATIOS[name]
                details.append(f"{name}={value[a]}÷{value[b]}={value[name]}" if value[b] else f"{name}分母为零，未定义")
            else:
                details.append(f"{name}={value[name]}")
        return (f"独立读取{audit.manifest['id']}的原始CSV，范围[{start},{end})。{rule}"
                + "；".join(details) + "。逐笔订单、首单、账户次数和月末合格卡的核算清单见artifacts/w03/test-preparation/independent_expected_values.json对应日期项；由customer/w03/independent_expectations.py逐记录计算，不读取指标库、被测SQL或Agent结果。")
    cases = []
    def ok(cid, question, ids, rule, start="2026-08-01", end="2026-09-01", group=None, filters=None, rows=None, source_text=None):
        intent = {"metrics":ids,"start":start,"end":end,"group_by":group or [],"filters":filters or []}
        expected = {"status":"ok","intent":intent,"columns":(group or [])+ids,
                    "rows":rows if rows is not None else [[values(start,end)[k] for k in ids]],
                    "units":{k:unit(k) for k in ids}, **versions}
        cases.append({"id":cid,"question":question,"expected":expected,
                      "expected_source":source_text or source(start,end,ids,rule)})
    # Preserve the learner's first three questions and checked expectations.
    for case in original:
        if case["id"] not in {"aug-net-sales", "aug-order-counts", "aug-cancel-refund-counts"}:
            continue
        ids = case["expected"]["intent"]["metrics"]
        start = case["expected"]["intent"]["start"];end = case["expected"]["intent"]["end"]
        wanted = [[values(start,end)[k] for k in ids]]
        if case["expected"]["rows"] != wanted:
            raise ValueError("PREVIOUS_CASE_NEEDS_REVIEW:"+case["id"])
        case["expected"].update(versions)
        cases.append(case)
    ok("aug-payment-refund-discount", "2026年8月青禾的实付金额、退款金额、支付订单原价金额和优惠金额分别是多少？",
       ["payment_cents","refund_cents","gross_cents","discount_cents"], "按《订单日报说明》仅汇总paid订单，优惠为原价减实付，退款不冲减优惠。")
    ok("aug-account-store-items", "2026年8月青禾的购买会员数、退款会员数、成交门店数和有效订单商品件数分别是多少？",
       ["buyer_count","refund_buyer_count","selling_store_count","valid_order_items"], "依据《订单日报说明》及学员确定的本期退款账户日期选择：购买账户和成交门店从有效订单去重；退款账户从paid且退款大于零的订单去重，包含部分与全退，默认全渠道；件数汇总有效订单原始quantity。")
    ok("aug-new-accounts", "2026年8月青禾新注册的CRM账户有多少个？", ["new_member_count"], "按《会员运营周报》读取members.registered_at计数，不用订单日期。")
    ok("july-new-accounts", "2026年7月青禾新注册的CRM账户有多少个？", ["new_member_count"], "按《会员运营周报》读取members.registered_at计数；与8月无新增的用例配对，检查真实注册月份和非零人数。",start="2026-07-01",end="2026-08-01")
    ok("aug-averages-frequency", "2026年8月青禾的有效订单均额、购买会员人均消费、购买频次和单均商品件数分别是多少？",
       ["avg_order_value","avg_buyer_value","purchase_frequency","items_per_order"], "按《财务邮件》分别使用净销售额/有效订单数、净销售额/购买账户数、有效订单数/购买账户数、商品件数/有效订单数。")
    ok("aug-refund-cancel-discount-rates", "2026年8月青禾的退款金额占比、取消率、退款订单率和优惠率分别是多少？",
       ["refund_amount_rate","cancel_rate","refund_order_rate","discount_rate"], "按《财务邮件》分子分母；原始比率不乘100，零分母未定义。")
    ok("aug-observed-first-repeat", "2026年8月青禾的观测期首购会员数、观测期首单数、观测期首单净销售额和观测期后续购买订单数分别是多少？",
       ["first_buyer_count","first_order_count","first_order_sales_cents","repeat_order_count"], "按《会员运营周报》在全覆盖期筛有效订单，逐账户按日期和订单号排序，先选首单或后续订单再筛8月；不是终身首购或月内复购人数。")
    monthly = ["monthly_buyer_count","monthly_repeat_buyer_count","monthly_repeat_rate"]
    ok("aug-monthly-repeat", "2026年8月青禾全渠道全门店的月内购买会员数、月内复购会员数和月内复购率分别是多少？", monthly,
       "按《会员运营周报》逐账户统计当月有效订单，至少1笔算购买、至少2笔算复购；不筛付费资格。")
    paid = ["monthly_paid_buyer_count","monthly_paid_order_count","monthly_paid_sales_cents","monthly_paid_repeat_buyer_count","monthly_paid_repeat_rate","monthly_paid_avg_order_value"]
    rule = "按《统计确认邮件》、小林MSG-04307和陈姐MSG-04333，月底存在悦享年卡或家庭季卡且开始日≤月底<计划结束日、提前终止日为空或月底<提前终止日的账户有资格；账户去重后取整月有效订单，不检查下单当天卡资格，再求人数、单数、净销售额及比率。"
    for month in (7,8):
        ok(f"month-{month}-paid-members", f"2026年{month}月青禾全渠道全门店的月末付费会员购买人数、有效订单数、净销售额、复购人数、复购率和订单均额分别是多少？", paid, rule,
           start=f"2026-{month:02d}-01",end=f"2026-{month+1:02d}-01")
    for group, word in [("store","订单成交门店编号"),("home_store","会员归属门店编号")]:
        rows = audit.net_sales_groups("2026-07-01","2026-08-01",group)
        ok("july-net-by-"+group, f"2026年7月青禾的净销售额按{word}分组分别是多少？", ["net_sales_cents"], "",start="2026-07-01",end="2026-08-01",group=[group],rows=rows,
           source_text=f"按《订单日报说明》《数据字典》，从原始orders.csv按下单日期取7月订单，paid取实付减退款，其他取0；{'直接使用orders.store_id' if group=='store' else '通过member_id查members.home_store_id'}分组求和，独立结果为{rows}。不混用成交和归属门店；数据版本{audit.manifest['id']}。")
    rows = audit.net_sales_groups("2026-08-01","2026-09-01","member__tier")
    ok("aug-net-by-tier", "2026年8月青禾按CRM会员等级分组的净销售额分别是多少？", ["net_sales_cents"], "",group=["member__tier"],rows=rows,
       source_text=f"原始8月paid订单实付减退款，按member_id关联members.tier后汇总，不以等级判断付费资格。数据{audit.manifest['id']}，独立结果{rows}。")
    for cid,question,channel,store,filters in [
        ("aug-store-channel-net","2026年8月青禾订单渠道为门店的净销售额是多少？","门店",None,[{"field":"order__channel","op":"eq","value":"门店"}]),
        ("aug-s01-miniapp-net","2026年8月青禾成交门店编号为S01、订单渠道为小程序的净销售额是多少？","小程序","S01",[{"field":"store","op":"eq","value":"S01"},{"field":"order__channel","op":"eq","value":"小程序"}]),
    ]:
        value,order_ids=audit.filtered_net_sales("2026-08-01","2026-09-01",channel,store)
        ok(cid,question,["net_sales_cents"],"",filters=filters,rows=[[value]],source_text=f"原始CSV筛选8月、渠道{channel}、成交门店{store or '不限'}，窗口内匹配订单{order_ids}；其中仅paid实付减退款求和={value}分。条件是AND，按成交门店而非归属门店。数据{audit.manifest['id']}。")
    rows=[]
    for start,end in [("2026-07-01","2026-08-01"),("2026-08-01","2026-09-01")]:
        v=values(start,end);rows.append([start+" 00:00:00",*[v[k] for k in monthly]])
    ok("july-aug-repeat-by-month", "请按自然月分别列出2026年7月和8月青禾全渠道全门店的月内购买会员数、月内复购会员数和月内复购率，不合并两个月的人数。", monthly,"",start="2026-07-01",group=["metric_time__month"],rows=rows,
       source_text="依据《会员运营周报》，独立按账户和自然月计有效订单，逐月算购买、复购和比率，不跨月加人数。两个月的账户次数和结果见independent_expected_values.json。分组键是月份首日零点，按框架日期时间字符串表示。")
    ok("aug-net-synonym", "2026年8月青禾已支付订单扣掉退款后，净销售额合计多少钱？", ["net_sales_cents"], "与净销售额正式定义同义，固定为全8月，不增加筛选。")
    ok("empty-month-zero-null", "2026年5月青禾的净销售额、有效订单数和退款金额占比分别是多少？", ["net_sales_cents","valid_order_count","refund_amount_rate"], "覆盖期内5月没有订单，金额和计数为0，退款金额占比分母实付为0，未定义为null。",start="2026-05-01",end="2026-06-01")
    ok("aug-last-day-boundary", "2026年8月31日当天青禾的创建订单数和净销售额分别是多少？", ["order_count","net_sales_cents"], "只取下单日期8月31日，时间区间左闭右开，8月其他日期不计。",start="2026-08-31")
    def nonok(cid,question,status,why):
        cases.append({"id":cid,"question":question,"expected":{"status":status},"expected_source":why})
    nonok("needs-period","青禾的净销售额是多少？","clarify","未给时间范围，按查询契约应先澄清，不能默认8月。")
    nonok("outside-coverage","2026年9月青禾的净销售额是多少？","unsupported","数据覆盖到2026-09-01，结束日不含；9月无覆盖，不能回答零。")
    nonok("half-month-repeat","2026年8月1日至8月15日青禾的月内复购率是多少？","unsupported","月内复购率只支持完整自然月，半个月不支持。")
    nonok("paid-report-by-store","2026年8月青禾按成交门店分别统计月末付费会员净销售额是多少？","unsupported","六项付费月报只支持全门店，不支持按成交门店拆分。")
    nonok("monthly-channel-filter","2026年8月青禾只看门店渠道的月内复购率是多少？","unsupported","当前完整月份策略不支持渠道筛选，不能绕过整月全渠道全门店限制。")
    nonok("multi-month-without-group","把2026年7月和8月青禾的月内购买会员数直接合成一个总数，不要按月列出。","unsupported","跨多月的月内指标须按月展示，不能把月去重人数加总为跨月人数。")
    nonok("unknown-store","2026年8月青禾成交门店编号为S99的净销售额是多少？","unsupported","S99不在当前测试库门店范围，按契约不支持，不能当作已知零值。")
    generated_ids = {c["id"] for c in cases}
    for case in original:
        if case["id"] not in generated_ids and case["id"] != "june-empty-and-null":
            cases.append(case)
    ids=[c["id"] for c in cases]
    assert len(ids)==len(set(ids))
    targets={x["id"] for x in json.loads((HERE/'targets.json').read_text())}
    covered={m for c in cases if c['expected']['status']=='ok' for m in c['expected']['intent']['metrics']}
    assert covered==targets,(targets-covered,covered-targets)
    for c in cases:
        e=c['expected']
        if e['status']=='ok':
            assert all(len(row)==len(e['columns']) for row in e['rows'])
            assert set(e['units'])==set(e['intent']['metrics'])
    (OUT/'independent_expected_values.json').write_text(json.dumps({'data_version':audit.manifest['id'],'csv_sha256':audit.hashes,'periods':periods,'note':'原始CSV独立期望，不是Agent实际输出；退款日期为学员确定的本期选择。'},ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    (HERE/'tests.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    (OUT/'coverage.json').write_text(json.dumps({'case_count':len(cases),'ok_cases':sum(c['expected']['status']=='ok' for c in cases),'covered_ids':sorted(covered),'missing_ids':sorted(targets-covered),'live_test_performed':False},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'cases':len(cases),'covered_metrics':len(covered),'live_test_performed':False},ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', default='.runtime/qinghe-small-v1')
    args = parser.parse_args()
    main(args.project)
