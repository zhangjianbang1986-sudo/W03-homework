WITH valid_orders AS (
  SELECT * FROM {{ ref('orders') }}
  WHERE status = 'paid' AND (paid_cents - refund_cents) > 0
),
member_month AS (
  SELECT member_id,
         CAST(date_trunc('month', ordered_at) AS DATE) AS month_start,
         COUNT(*) AS valid_order_count,
         SUM(paid_cents - refund_cents) AS valid_net_sales_cents
  FROM valid_orders
  GROUP BY member_id, CAST(date_trunc('month', ordered_at) AS DATE)
)
SELECT
  member_id || '|' || CAST(month_start AS VARCHAR) AS member_month_key,
  member_id,
  month_start,
  valid_order_count,
  valid_net_sales_cents,
  CASE WHEN valid_order_count >= 2 THEN TRUE ELSE FALSE END AS is_repeat_buyer
FROM member_month