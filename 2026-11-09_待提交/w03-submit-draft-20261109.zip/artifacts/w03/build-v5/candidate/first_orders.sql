with valid_orders as (
  select order_id, member_id, store_id, ordered_at, status, channel, gross_cents, paid_cents, refund_cents,
         paid_cents - refund_cents as net_sales_cents
  from {{ ref('orders') }}
  where status = 'paid' and paid_cents - refund_cents > 0
), ranked as (
  select *, row_number() over (partition by member_id order by ordered_at, order_id) as rn
  from valid_orders
)
select order_id, member_id, store_id, ordered_at, status, channel, gross_cents, paid_cents, refund_cents, net_sales_cents
from ranked
where rn = 1