WITH valid_orders AS (
  SELECT
    order_id,
    member_id,
    ordered_at,
    paid_cents - refund_cents AS net_sales_cents
  FROM {{ ref('orders') }}
  WHERE status = 'paid' AND paid_cents - refund_cents > 0
),
monthly_orders AS (
  SELECT
    member_id,
    CAST(DATE_TRUNC('month', ordered_at) AS DATE) AS month_start,
    COUNT(DISTINCT order_id) AS valid_order_count,
    SUM(net_sales_cents) AS net_sales_cents
  FROM valid_orders
  GROUP BY member_id, CAST(DATE_TRUNC('month', ordered_at) AS DATE)
),
monthly_orders_with_end AS (
  SELECT
    member_id,
    month_start,
    CAST(month_start + INTERVAL '1 month' - INTERVAL '1 day' AS DATE) AS month_end,
    valid_order_count,
    net_sales_cents
  FROM monthly_orders
),
paid_cards AS (
  SELECT
    member_id,
    valid_from,
    valid_until,
    ended_at
  FROM {{ ref('cards') }}
  WHERE card_type IN ('悦享年卡', '家庭季卡')
),
eligible AS (
  SELECT DISTINCT
    mo.member_id,
    mo.month_start
  FROM monthly_orders_with_end mo
  WHERE EXISTS (
    SELECT 1
    FROM paid_cards pc
    WHERE pc.member_id = mo.member_id
      AND pc.valid_from <= mo.month_end
      AND pc.valid_until > mo.month_end
      AND (pc.ended_at IS NULL OR pc.ended_at > mo.month_end)
  )
)
SELECT
  mo.member_id,
  mo.month_start,
  mo.valid_order_count,
  mo.net_sales_cents,
  mo.member_id || '|' || CAST(mo.month_start AS VARCHAR) AS member_month_key
FROM monthly_orders_with_end mo
JOIN eligible e
  ON mo.member_id = e.member_id
 AND mo.month_start = e.month_start